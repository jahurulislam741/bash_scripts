

#rm video_clip/*

# this script creates image sequence from a given video file
# "fps = 30" means 30 frames will be saved per second

filename="laval24"
fps=30

#ffmpeg -i video-clips/laval78.mp4 -vf fps=1 1-input-images/img%d.png
ffmpeg -i video_clip/$filename.mp4 -vf fps=$fps extracted_image_frames/$filename-%d.png


