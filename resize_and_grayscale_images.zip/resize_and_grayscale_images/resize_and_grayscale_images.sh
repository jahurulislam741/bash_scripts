#!/bin/bash

# Start the timer
start_time=$(date +%s.%N)

# Input directory containing the images
input_dir="1_input_images"

# Output directory to store grayscaled images (subdirectories will be recreated)
output_dir="2_resized_and_grayscaled_images"

# Create output directory if it doesn't exist
rm -rf "$output_dir"
mkdir -p "$output_dir"

# Set the desired width and height for the resized images
new_width=900
new_height=1200


# Function to recursively process the images
process_images() {
    local current_dir=$1

    # Loop through each image in the current directory
    for image_file in "$current_dir"/*; do
        echo $image_file
        # Check if it's a directory
        if [[ -d "$image_file" ]]; then
            # Create corresponding directory in the output directory
            mkdir -p "$output_dir/${image_file#$input_dir}"

            # Recursively process images in the subdirectory
            process_images "$image_file"
        elif [[ -f "$image_file" ]]; then
            # Extract the filename and extension
            file_name=$(basename "$image_file")
            extension="${file_name##*.}"
            file_name_without_extension="${file_name%.*}"

            # Resize the image while preserving the aspect ratio
            convert "$image_file" -resize "${new_width}x${new_height}" "$output_dir/${image_file#$input_dir}"
            
            # Convert the resized image to grayscale
            convert "$output_dir/${image_file#$input_dir}" -colorspace Gray "$output_dir/${image_file#$input_dir}"
        fi
    done
}

# Call the function to process the images recursively
process_images "$input_dir"


# End the timer
end_time=$(date +%s.%N)
elapsed_time=$(echo "$end_time - $start_time" | bc)

# Print the elapsed time
echo "Script executed in $elapsed_time seconds."

