
# extract audio from video
#ffmpeg -i test.mp4 -vn -acodec pcm_s16le -ar 44100 -ac 2 output.wav

# convert stereo to mono
#ffmpeg -i stereo.wav -af "pan=mono|FC=FR" right_mono.wav


# EXTRACT AUDIO FROM SPEECH VIDEOS
input_dir='input_videos'
output_dir="output_audio"
rm -rf $output_dir # remove folder if exists
mkdir $output_dir
for f in $input_dir/*; 
    do
        fname=${f##*/} # keep string after the character "/"
        echo $fname
        fname=${fname::-4} # remove the last 4 characters of file extension (output file name)

        # extract audio from video
        ffmpeg -v quiet -stats -i $f -vn -acodec pcm_s16le -ar 22050 -ac 2 ${fname}_stereo.wav # "-v quiet -stats" extra messages in terminal

        # convert the audio file to single channel
        ffmpeg  -v quiet -stats -i ${fname}_stereo.wav -c:v copy -ac 1 $output_dir/${fname}.wav # convert stereo to mono
#        ffmpeg -v quiet -stats -i ${fname}_p.wav -ac 1 -ar 22050 -c:a pcm_s16le -q:a 9 $output_dir/${fname}.wav # resample to 22050 Hz
        # ffmpeg -v quiet -stats -i in.mov out.mp4 # "-v quiet -stats" extra messages in terminal
        rm ${fname}_stereo.wav
    done



