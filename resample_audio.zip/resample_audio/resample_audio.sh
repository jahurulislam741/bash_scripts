

dir_proc_audio="resampled_audio"
rm -rf $dir_proc_audio # remove folder if exists
mkdir $dir_proc_audio
for f in original_audio/*; 
    do
        # convert the audio file to single channel
        fname=${f##*/} # keep string after the character "/"
        echo $fname
        fname=${fname::-4} # remove the last 4 characters of file extension (output file name)
        ffmpeg  -v quiet -stats -i $f -c:v copy -ac 1 ${fname}_p.wav # convert stereo to mono
        ffmpeg -v quiet -stats -i ${fname}_p.wav -ac 1 -ar 22050 -ac 1 $dir_proc_audio/${fname}.wav

#        ffmpeg -i [source file] -vn -ar 16000 -ac 1 [destination file]
 # resample to 22050 Hz
        # ffmpeg -v quiet -stats -i in.mov out.mp4 # "-v quiet -stats" suppresses the detailed output messages in terminal
        rm ${fname}_p.wav
    done
