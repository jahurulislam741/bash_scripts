#!/bin/bash

# Video Enhancement Script
#
# This script automates the process of enhancing video quality by processing the input videos through a series of steps including audio extraction, frame extraction, frame enhancement, and reassembly into a final enhanced video file. It utilizes `ffmpeg` for video manipulation (extraction of frames and audio, video creation) and `upscayl-ncnn` for frame enhancement.
#
# Prerequisites:
# - `ffmpeg` must be installed and available in the system's PATH.
# - `upscayl-ncnn` must be compiled and the binary path is specified within this script.
#
# Usage:
# - Place input video files in the "1_input_videos" directory.
# - Ensure the output directory "2_enhanced_videos" does not exist or is empty (it will be recreated).
# - Run the script. The script processes all `.mp4` files found in the input directory.
#
# How it works:
# 1. Prepares environment by setting up input and output directories.
# 2. Loops through all `.mp4` files in the input directory.
# 3. For each video file:
#    a. Extracts the audio and saves it temporarily.
#    b. Extracts frames at the original frame rate.
#    c. Enhances each extracted frame using `upscayl-ncnn`.
#    d. Reassembles the enhanced frames and the original audio into a final video file in the output directory.
# 4. Cleans up temporary files and directories.
#
# Features:
# - Error handling to stop execution upon encountering an error.
# - Dynamic frame rate calculation to maintain the original video's timing.
# - Parallel processing of frame enhancement to improve performance.
# - Cleanup of temporary files to prevent storage waste.
#
# Output:
# - Enhanced videos are saved in the "2_enhanced_videos" directory with the same base name as the input files.
# - Reports the total script execution time in seconds.
#
# Note:
# This script assumes `ffprobe` is available in the system's PATH for frame rate calculation.
# Modify the `upscayl_bin` path as needed to point to your `upscayl-ncnn` binary.
#
# Author: <Jahurul Islam>
# Date: <Feb. 21, 2024>
# License: <MIT>


set -e

start_time=$(date +%s)

# Directories
input_dir="1_input_videos"
output_base_dir="2_enhanced_videos"
rm -rf "$output_base_dir"

# Path to upscayl binary and ffprobe
upscayl_bin="/home/jahir/upscayl-ncnn/build/upscayl-bin"
ffprobe_bin="ffprobe" # Assuming ffprobe is in the PATH

# File format to search for
file_format="mp4"

# Loop through all video files in the input directory
echo "Starting video processing..."
for video_file in "$input_dir"/*.$file_format; do
    if [ ! -f "$video_file" ]; then
        echo "No $file_format files found in $input_dir."
        continue
    fi

    base_name=$(basename "$video_file" .$file_format)
    file_name=$(basename "$video_file")

    
    # Temporary directories for this video's processing
    extracted_frames_dir=$(mktemp -d)
    processed_frames_dir=$(mktemp -d)
    audio_extract_path=$(mktemp).aac # Temporary file for audio

    # Final output video path
    final_video_path="$output_base_dir/${base_name}.mp4"
    mkdir -p "$output_base_dir"

    # Use ffprobe to get the FPS as a fraction
    fps_fraction=$($ffprobe_bin -v 0 -of csv=p=0 -select_streams v:0 -show_entries stream=r_frame_rate "$video_file")
    # Convert the fraction to decimal
    frame_rate=$(echo "scale=2; $fps_fraction" | bc -l)
#    frame_rate=1 # for test purpose only

    echo "Frame rate for $file_name is $frame_rate"

    # Extract audio from the original video
    echo "Extracting audio from $file_name..."
    ffmpeg -i "$video_file" -vn -acodec copy "$audio_extract_path" > /dev/null 2>&1


    # Step 1: Extract frames
    echo "Extracting frames from $file_name..."
    ffmpeg -i "$video_file" -vf "fps=$frame_rate" "$extracted_frames_dir/frame_%06d.png" > /dev/null 2>&1


    # Step 2: Process (enhance) frames
    echo "Processing (enhancing) frames for $file_name..."
#    for image_file in "$extracted_frames_dir"/*.png; do
#        image_name=$(basename "$image_file")
#        input_path="$image_file"
#        output_path="$processed_frames_dir/$image_name"
#        $upscayl_bin -i "$input_path" -o "$output_path" > /dev/null 2>&1
#    done

    # Make "filelist.txt"
    find "$extracted_frames_dir" -name '*.png' > filelist.txt

    # Run parallel processing
    cat filelist.txt | xargs -I{} -n 1 -P 8 sh -c '
        upscayl_bin="/home/jahir/upscayl-ncnn/build/upscayl-bin"
        input_path="$1";
        output_path="'"$processed_frames_dir"'"/$(basename "$input_path");
        $upscayl_bin -i "$input_path" -o "$output_path" > /dev/null 2>&1
    ' sh {}

    rm filelist.txt

    # Step 3: Create video from processed frames
    echo "Creating video for $file_name..."
    ffmpeg -framerate "$frame_rate" -i "$processed_frames_dir/frame_%06d.png" -i "$audio_extract_path" -c:v libx264 -pix_fmt yuv420p -c:a copy -shortest "$final_video_path" > /dev/null 2>&1

    # Cleanup temporary directories and audio file
    rm -r "$extracted_frames_dir" "$processed_frames_dir"
    rm "$audio_extract_path"
    
    echo "$file_name processing completed."
    echo 
done

echo "All videos processed."


end_time=$(date +%s)
execution_time=$((end_time - start_time))
echo "Script execution time: $execution_time seconds."

